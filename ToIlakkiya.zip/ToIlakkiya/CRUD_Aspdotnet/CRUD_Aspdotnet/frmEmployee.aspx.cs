﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CRUD_Aspdotnet
{
    public partial class frmEmployee : System.Web.UI.Page
    {
        SqlConnection objSqlConnection = new SqlConnection(@"Data Source=DESKTOP-U27RV0I\SQL2016;Initial Catalog=TestDB;User ID=sa;Password=Sql@2016");

        private void OpenConnection()
        {
            if (objSqlConnection.State == ConnectionState.Closed)
            {
                objSqlConnection.Open();
            }
        }

        private void CloseConnection()
        {
            if (objSqlConnection.State == ConnectionState.Open)
            {
                objSqlConnection.Close();
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadGrid();
            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            OpenConnection();
            int nresult = 0;
            SqlCommand cmd = new SqlCommand("sp_SaveDelete_SmpEmployee");
            cmd.Connection = objSqlConnection;
            cmd.Parameters.AddWithValue("@A_EmployeeId", string.IsNullOrEmpty(hdnEmployeeId.Value) ? 0 : Convert.ToInt32(hdnEmployeeId.Value));
            cmd.Parameters.AddWithValue("@A_EmployeeName", txtEmpName.Text);
            cmd.Parameters.AddWithValue("@A_Address", txtEmpAddress.Text);
            cmd.Parameters.AddWithValue("@A_MobileNo", txtEmpMobile.Text);
            cmd.Parameters.AddWithValue("@A_SelectFor", "Save");
            cmd.Parameters.Add("@A_RetVal", SqlDbType.VarChar, 4000);
            cmd.Parameters.Add("@A_RetMessage", SqlDbType.VarChar, 4000);
            cmd.Parameters["@A_RetVal"].Direction = ParameterDirection.Output;
            cmd.Parameters["@A_RetMessage"].Direction = ParameterDirection.Output;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
            nresult = Convert.ToInt32(cmd.Parameters["@A_RetVal"].Value);
            var nmsg = cmd.Parameters["@A_RetMessage"].Value.ToString();
            Response.Write("<script>alert('" + nmsg + "')</script>");
            CloseConnection();
            Cancel();
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Cancel();
        }

        private void Cancel()
        {
            LoadGrid();
            txtEmpName.Text = "";
            txtEmpAddress.Text = "";
            txtEmpMobile.Text = "";
            hdnEmployeeId.Value = "";
        }

        private void LoadGrid()
        {
            OpenConnection();
            string SqlQuery = "Select * from Smp_Employee";
            SqlDataAdapter objSqlDataAdapter = new SqlDataAdapter(SqlQuery, objSqlConnection);
            objSqlDataAdapter.SelectCommand.CommandType = CommandType.Text;
            DataTable dttbl = new DataTable();
            objSqlDataAdapter.Fill(dttbl);
            CloseConnection();

            gvEmployee.DataSource = dttbl;
            gvEmployee.DataBind();
        }

        protected void gvEmployee_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            GridViewRow row = (GridViewRow)((Control)e.CommandSource).NamingContainer;
            int rowIndex = row.RowIndex;

            if ((((System.Web.UI.WebControls.LinkButton)(e.CommandSource)).CommandName).ToUpper() == "EDIT")
            {
                hdnEmployeeId.Value = row.Cells[0].Text;
                txtEmpName.Text = row.Cells[1].Text;
                txtEmpAddress.Text = row.Cells[2].Text;
                txtEmpMobile.Text = row.Cells[3].Text;
            }
            else if ((((System.Web.UI.WebControls.LinkButton)(e.CommandSource)).CommandName).ToUpper() == "DELETE")
            {                
                hdnEmployeeId.Value = row.Cells[0].Text;
                OpenConnection();
                int nresult = 0;
                SqlCommand cmd = new SqlCommand("sp_SaveDelete_SmpEmployee");
                cmd.Connection = objSqlConnection;
                cmd.Parameters.AddWithValue("@A_EmployeeId", string.IsNullOrEmpty(hdnEmployeeId.Value) ? 0 : Convert.ToInt32(hdnEmployeeId.Value));
                cmd.Parameters.AddWithValue("@A_EmployeeName", txtEmpName.Text);
                cmd.Parameters.AddWithValue("@A_Address", txtEmpAddress.Text);
                cmd.Parameters.AddWithValue("@A_MobileNo", txtEmpMobile.Text);
                cmd.Parameters.AddWithValue("@A_SelectFor", "Delete");
                cmd.Parameters.Add("@A_RetVal", SqlDbType.VarChar, 4000);
                cmd.Parameters.Add("@A_RetMessage", SqlDbType.VarChar, 4000);
                cmd.Parameters["@A_RetVal"].Direction = ParameterDirection.Output;
                cmd.Parameters["@A_RetMessage"].Direction = ParameterDirection.Output;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.ExecuteNonQuery();
                nresult = Convert.ToInt32(cmd.Parameters["@A_RetVal"].Value);
                var nmsg = cmd.Parameters["@A_RetMessage"].Value.ToString();
                Response.Write("<script>alert('" + nmsg + "')</script>");
                CloseConnection();
                Cancel();
            }

        }

        protected void gvEmployee_RowEditing(object sender, GridViewEditEventArgs e)
        {

        }

        protected void gvEmployee_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
           
        }
    }
}

